
class GameState():
    def __init__(self):
        self.board =[
            ["bR", "bN", "bB", "bQ", "bK", "bB", "bN", "bR"],
            ["bp", "bp", "bp", "bp", "bp", "bp", "bp", "bp"],
            ["--", "--", "--", "--", "--", "--", "--", "--"],
            ["--", "--", "--", "--", "--", "--", "--", "--"],
            ["--", "--", "--", "--", "--", "--", "--", "--"],
            ["--", "--", "--", "--", "--", "--", "--", "--"],
            ["wp", "wp", "wp", "wp", "wp", "wp", "wp", "wp"],
            ["wR", "wN", "wB", "wQ", "wK", "wB", "wN", "wR"]]
        self.moveFunctions = {"p": self.getPawnMoves, "R": self.getRookMoves, "N": self.getKnightMoves,
                              "B": self.getBishopMoves, "Q": self.getQueenMoves, "K": self.getKingMoves}
        self.whiteTomove= True
        self.movelog=[]
        self.white_king_location = (7, 4)
        self.black_king_location = (0, 4)
        self.checkmate = False
        self.stalemate = False
        self.in_check = False
        self.pins = []
        self.checks = []
        self.enpassant_possible = ()  # coordinates for the square where en-passant capture is possible
        self.enpassant_possible_log = [self.enpassant_possible]
        self.current_castling_rights = CastleRights(True, True, True, True)
        self.castle_rights_log = [CastleRights(self.current_castling_rights.wks, self.current_castling_rights.bks,
                                               self.current_castling_rights.wqs, self.current_castling_rights.bqs)]


    def makeMove(self, move):
        self.board[move.startRow][move.startCol] = "--"
        self.board[move.endRow][move.endCol] = move.pieceMoved
        self.movelog.append(move) #we save the last move to call it later if we want to undo it
        self.whiteTomove= not self.whiteTomove #swap players

    '''
    THis function to undo a move
    '''
    def UndoMove(self):
        if len(self.movelog) != 0:  # this condition is to check there is move to undo
            move = self.movelog.pop()
            self.board[move.startRow][move.startCol] = move.pieceMoved
            self.board[move.endRow][move.endCol] = move.pieceCaptured
            self.whiteTomove = not self.whiteTomove  # switch turns back

    '''
    function for the valid moves
    '''
    def getValidMoves(self):
        return self.getAllPossibleMoves()

    '''
    it will consider all possible moves without considering checks
    '''
    def getAllPossibleMoves(self):
        moves = []
        for row in range(len(self.board)):
            for col in range(len(self.board[row])):
                turn = self.board[row][col][0]
                if (turn == "w" and self.whiteTomove) or (turn == "b" and not self.whiteTomove):
                    piece = self.board[row][col][1]
                    self.moveFunctions[piece](row, col, moves)  # calls appropriate move function based on piece type



                #self.moveFunctions[piece](r,c,moves) #calls the appropriate move function based on piece type
        return moves

    '''
    get all the pawn moves in the current row,col and added to moves list above
    '''
    def getPawnMoves(self,r,c, moves):
        if self.whiteTomove:  #white pawn moves
            if self.board[r-1][c] == "--": #1 square pawn advance
                moves.append(Move((r,c),(r-1,c),self.board))
                if r== 6 and self.board[r-2][c]== "--":  #2 square pawn advance
                    moves.append(Move((r,c),(r-2,c), self.board))
            if c-1 >= 0: #captures to the left
                if self.board[r-1][c-1][0]== 'b': #there is opponent piece to capture
                    moves.append(Move((r,c),(r-1,c-1), self.board))
                if c+1 <= 7: #captures to the right
                    if self.board[r-1][c+1][0]== 'b': #there is opponent piece to capture
                        moves.append(Move((r, c), (r - 1, c + 1), self.board))


        else: #black pawn moves
            if self.board[r+1][c] == "--": #1 square pawn advance
                moves.append(Move((r,c),(r + 1,c),self.board))
                if r== 1 and self.board[r + 2][c]== "--":  #2 square pawn advance
                    moves.append(Move((r,c),(r + 2,c), self.board))

            if c - 1 >= 0: #captures to the left
                if self.board[r + 1][c - 1][0]== 'w': #there is opponent piece to capture
                    moves.append(Move((r,c),(r + 1,c - 1), self.board))
                if c+1 <= 7: #captures to the right
                    if self.board[r+1][c+1][0]== 'w': #there is opponent piece to capture
                        moves.append(Move((r, c), (r + 1, c + 1), self.board))



    '''
    get all the Rook moves in the current row,col and added to moves list above
     '''
    def getRookMoves(self, r, c, moves):
        """
        Get all the rook moves for the rook located at row, col and add the moves to the list.
        """

        directions = ((-1, 0), (0, -1), (1, 0), (0, 1))  # left, down, up, right
        enemy_color = "b" if self.whiteTomove else "w"
        for d in directions:
            for i in range(1, 8):
                end_row = r + d[0] * i
                end_col = c + d[1] * i
                if 0 <= end_row <= 7 and 0 <= end_col <= 7:  # check for possible moves only in boundaries of the board
                        end_piece = self.board[end_row][end_col]
                        if end_piece == "--":  # empty space is valid
                            moves.append(Move((r, c), (end_row, end_col), self.board))
                        elif end_piece[0] == enemy_color:  # capture enemy piece
                            moves.append(Move((r, c), (end_row, end_col), self.board))
                            break
                        else:  # friendly piece
                            break
                else:  # off board
                    break



    '''
        get all the Bishop moves in the current row,col and added to moves list above
    '''

    def getBishopMoves(self, r, c, moves):
        directions = ((-1, -1), (-1, 1), (1, -1), (1, 1))  # moving diagonal
        enemy_color = "b" if self.whiteTomove else "w"
        for d in directions:
            for i in range(1, 8):
                end_row = r + d[0] * i
                end_col = c + d[1] * i
                if 0 <= end_row <= 7 and 0 <= end_col <= 7:  # check for possible moves only in boundaries of the board
                    end_piece = self.board[end_row][end_col]
                    if end_piece == "--":  # empty space is valid
                        moves.append(Move((r, c), (end_row, end_col), self.board))
                    elif end_piece[0] == enemy_color:  # capture enemy piece
                        moves.append(Move((r, c), (end_row, end_col), self.board))
                        break
                    else:  # friendly piece
                        break
                else:  # off board
                    break


    '''
    get all the Queen moves in the current row,col and added to moves list above
    '''

    def getQueenMoves(self, r, c, moves):
        self.getRookMoves(r,c,moves)
        self.getBishopMoves(r, c, moves)

    '''
    get all the Knight moves in the current row,col and added to moves list above
    '''

    def getKnightMoves(self, r, c, moves):
        KnightMoves = ((-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1))
        allyColor = "w" if self.whiteTomove else "b"
        for m in KnightMoves:
            end_row = r + m[0]
            end_col = c + m[1]
            if 0 <= end_row <= 7 and 0 <= end_col <= 7:
                end_piece = self.board[end_row][end_col]
                if end_piece[0] != allyColor:
                    moves.append(Move((r, c), (end_row, end_col), self.board))

    '''
    get all the King moves in the current row,col and added to moves list above
    '''

    def getKingMoves(self, r, c, moves):
        KingMoves = ((-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1))
        allyColor = "w" if self.whiteTomove else "b"
        for m in KingMoves:
            end_row = r + m[0]
            end_col = c + m[1]
            if 0 <= end_row <= 7 and 0 <= end_col <= 7:
                end_piece = self.board[end_row][end_col]
                if end_piece[0] != allyColor:
                    moves.append(Move((r, c), (end_row, end_col), self.board))


class Move():
    ranksToRows={"1": 7, "2": 6, "3": 5, "4": 4,
                 "5": 3, "6": 2, "7": 1, "8": 0}
    rowsToRanks= {v: k for k, v in ranksToRows.items()}
    filesToCols={"a": 0, "b": 1, "c": 2, "d": 3,
                 "e": 4, "f": 5, "g": 6, "h": 7}
    colsToFiles={v: k for k, v in filesToCols.items()}


    def __init__(self, startSq, endSq, board):
        self.startRow = startSq[0]
        self.startCol = startSq[1]
        self.endRow = endSq[0]
        self.endCol = endSq[1]
        self.pieceMoved= board[self.startRow][self.startCol]
        self.pieceCaptured= board[self.endRow][self.endCol]
        self.moveID = self.startRow *1000 + self.startCol * 100 + self.endRow * 10 + self.endCol



    def __eq__(self, other):
        if isinstance(other, Move):
            return self.moveID == other.moveID
        return False


    def getChessNotation(self):
        return self.getRankFile(self.startRow,self.startCol) + self.getRankFile(self.endRow,self.endCol)

    def getRankFile(self,r, c):
        return self.colsToFiles[c] + self.rowsToRanks[r]



class CastleRights:
    def __init__(self, wks, bks, wqs, bqs):
        self.wks = wks
        self.bks = bks
        self.wqs = wqs
        self.bqs = bqs









