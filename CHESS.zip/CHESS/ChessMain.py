import pygame as p
from CHESS import ChessEngine

p.init()
WIDTH= HEIGHT= 512
DIMENSION= 8
SQ_SIZE= HEIGHT//DIMENSION
MAX_FPS= 15

IMAGES={}

def loadImages():
    pieces=["bR", "bN", "bB", "bQ", "bK", "bB", "bN", "bR", "bp","wR", "wN", "wB", "wQ", "wK", "wB", "wN", "wR","wp"]
    for piece in pieces:
        IMAGES[piece]=p.image.load("images/"+ piece +".png")



def main():
    p.init()
    screen=p.display.set_mode((WIDTH,HEIGHT))
    clock =p.time.Clock()
    screen.fill(p.Color("white"))
    gs= ChessEngine.GameState()
    validMoves = gs.getValidMoves()
    MoveMade = False
    loadImages()
    running= True
    sqSelected=()
    playerClicks= []
    while running:
        for e in p.event.get():
            if e.type == p.QUIT:
                running= False
            #mouse clicks to move the piece
            elif e.type == p.MOUSEBUTTONDOWN:
                location = p.mouse.get_pos()
                col = location[0]//SQ_SIZE
                row = location[1]//SQ_SIZE
                if sqSelected == (row,col):
                    sqSelected = ()
                    playerClicks = []
                else:
                    sqSelected = (row,col)
                    playerClicks.append(sqSelected)
                if len(playerClicks) == 2:
                    move= ChessEngine.Move(playerClicks[0],playerClicks[1], gs.board)
                    print(move.getChessNotation())
                    if move in validMoves:
                        gs.makeMove(move)
                        MoveMade = True
                    sqSelected= ()
                    playerClicks= []
            elif e.type == p.KEYDOWN:
                if e.key == p.K_z: # will undo the move when press letter "z"
                    gs.UndoMove()
                    MoveMade = True
        if MoveMade:
            validMoves= gs.getValidMoves()
            MoveMade = False


        drawGameState(screen, gs)
        clock.tick(MAX_FPS)
        p.display.flip()

def drawGameState(screen, gs):
    drawboard(screen)
    drawPieces(screen,gs.board)


def drawboard(screen):
        colors=[p.Color("white"),p.Color("dark green")]
        for r in range(DIMENSION):
            for c in range(DIMENSION):
               color = colors[((r+c) % 2)]
               p.draw.rect(screen, color,p.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))


def drawPieces(screen,board):
    for row in range(DIMENSION):
        for column in range(DIMENSION):
            piece= board[row][column]
            if piece != "--":
                screen.blit(IMAGES[piece], p.Rect(column*SQ_SIZE, row*SQ_SIZE, SQ_SIZE, SQ_SIZE))





if __name__== "__main__":
    main()






























